# Be sure to restart your server when you modify this file.

TunR::Application.config.session_store :cookie_store, key: '_tunR_session'
