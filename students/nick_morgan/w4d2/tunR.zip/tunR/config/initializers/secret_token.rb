# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
TunR::Application.config.secret_key_base = 'c6d005758e6166ee8478e60118c281ea4cc6dafe5776500b13b3ef38afb1df291094e9fe2792d9a2f1a93623f98478b62f4d6a9ebe290412cd81d8779fc69d43'
