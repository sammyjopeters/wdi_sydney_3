require 'test_helper'

class ArtistsHelperTest < ActionView::TestCase
end
